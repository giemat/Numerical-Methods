clear all
close all
format compact
%Wywołanie
page_rank();

print -dpng zadanie4.png
%print -dpng zadanie5.png